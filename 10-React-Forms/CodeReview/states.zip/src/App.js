/* import logo from './logo.svg'; */
import './App.css';
//import ClassState from './Components/ClassState'
//import FuncState from './Components/FuncState'
/* import ArrayDes from './Components/ArrayDes' */
/* import ClassNesting from './Components/ClassNesting' */
/* import FuncNesting from './Components/FuncNesting' */




function App() {
  return (
    <div className="App">
      {/* <ClassState/> */}
      {/* <FuncState /> */}
      {/* <ArrayDes name="Andres"/> */}
      {/* <ClassNesting/> */}
      {/* <FuncNesting name="Andres"/> */}
      
    </div>
  );
}

export default App;
