import React, {Fragment} from 'react'
import ReactDOM from 'react-dom'

export default function FuncNesting (props){
    const name = props.name
    const amigos = ['toni', 'franco', 'emi', 'solano']

    return(
        <Fragment>
            <div style={{width: "250px", margin: "0 auto"}}>
                <h3>Nombre: {name}</h3>
                <MostrarLista amigos={amigos}/> {/*Components names always use BumpyCase */}
            </div>
        </Fragment>
    )
}

export function MostrarLista (props){ //export (not default) its used to export multiple components from a same file.

    return (
        <Fragment>
            <ul style={{listStyle: "none", textAlign: "left"}}>    
                
                {props.amigos.map((e,i) => (
                    <li key={i}>{e}</li>
                ))}
            </ul>
        </Fragment>
    )
}

ReactDOM.render(<FuncNesting />, document.getElementById('app'))