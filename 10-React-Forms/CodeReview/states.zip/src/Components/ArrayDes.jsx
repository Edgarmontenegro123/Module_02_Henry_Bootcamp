import React, {Fragment, useState, useRef} from 'react'
import ReactDOM from 'react-dom'


export default function ArrayDes (props) { //Always export default
    const [name, setName]= useState(props.name) // separating state and function elements with destructuring on different variables 
    const textInput = useRef(null) //useRef is also assigned to a textInput variable for latter use.

    const onButtonClick = (e)=>{
        e.preventDefault()
        const newName = textInput.current.value 
        setName(newName)
    }

    

    return (
        <Fragment>
            {console.log("1:", name)}

            <form onSubmit={onButtonClick}>
                <input type="text" ref={textInput} placeholder="Ingresa tu nombre.."/>
                <button>Cambiar</button>
            </form>

            <p>Hola {name}!!</p>
        </Fragment>
    )
}


ReactDOM.render(<ArrayDes />, document.getElementById('app'))