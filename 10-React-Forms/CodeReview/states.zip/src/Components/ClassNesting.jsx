import React, {Fragment} from 'react'
import ReactDOM from 'react-dom'

export default class ClassNesting extends React.Component{ //classes always extends from React.Component

    render(){
        const name = "Soy Angel"
        const amigos = ['Toni', 'Franco', 'Emi', 'Solano']

        return (
            <Fragment >
                <div style={{width: "200px", margin: "0 auto"}}>
                    <h3>Nombre: {name}</h3>
                    <MostrarLista names={amigos} />
                </div>
            </Fragment>
        )
    }
}



export class MostrarLista extends React.Component{

    render(){
        const lista = this.props.names.map((e,i) => (
            <li key={i}>{e}</li>
        ))

        return (
            <Fragment>
            <ul style={{listStyle: "none", textAlign: "left"}}>
                {lista}
            </ul>
            </Fragment>
        )
    }
}

ReactDOM.render(<ClassNesting/>, document.getElementById('app'))