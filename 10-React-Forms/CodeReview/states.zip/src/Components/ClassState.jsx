import React, {Fragment} from 'react'
import ReactDOM from 'react-dom'

export default class ClassState extends React.Component {
    constructor(props){
        super(props)
        this.state= ({name: this.props.name})
        this.onButtonClick = this.onButtonClick.bind(this)
    }

    onButtonClick(e){
        e.preventDefault() //prefiene la accion por defecto de onSubmit en form
        const newName = this.refs.name.value //la propiedad se llama refs y no ref

        this.setState({
            name: newName
        }) //los setstrate son funciones que reciben como parámetro un objeto
    }

    render(){ //render es un método
        return (
            <Fragment>
                <form onSubmit={this.onButtonClick}>
                    <input type="text" ref="name" placeholder="Ingresa tu nombre..."/>
                    <button>Tu nombre</button>
                </form>

                <p>Hola <strong>{this.state.name}</strong></p>
            </Fragment>
        )
    }
}

ReactDOM.render(<ClassState name="Angel"/>, document.getElementById('app'))