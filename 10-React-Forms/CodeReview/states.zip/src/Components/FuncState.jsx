import React, {Fragment, useState, useRef} from 'react'
import ReactDOM from 'react-dom'

export default function FuncState(props){ //always export default 
    const nameState = useState(props.name) //asigna a nameState el hook useState
    const textInput = useRef(null)
    

    const onButtonClick = (e) => {
        e.preventDefault()
        const newName = textInput.current.value
        nameState[1](newName)
    }

    return (
        <Fragment>
        {console.log(nameState)} 
        {/* useState contenido en nameState es un array con 2 elementos, el primero es el estado
        y el segundo una funcion que permite actualizarlo*/}
        
            <form onSubmit={onButtonClick}>
                <input type="text" ref={textInput} placeholder="Ingresa tu nombre..."/>
                <button>Cambiar</button>
            </form>

            <p>Hola {nameState[0]}!!</p>
        </Fragment>
    )

}



ReactDOM.render(<FuncState name="Angel"/>, document.getElementById('app'))